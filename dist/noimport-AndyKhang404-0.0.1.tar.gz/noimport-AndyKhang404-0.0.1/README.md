# noimport v0.0.1
A simple package to prevent the abusive use of 'import' statement in Python.
### Installation
To install, just run:
```
pip install noimport
```
### Usage
Just add this into the start of your `.py` file:
```
import noimport
```
:smiling_imp: Let see how far can you go without importing those modules and packages :smiling_imp:
